/*
 * AdEntry.cpp
 *
 *  Created on: Nov 16, 2015
 *      Author: supreeth
 */

#include "../include/AdEntry.h"
#include <stdlib.h>
#include <iostream>
#include <string.h>

AdEntry::AdEntry() {
	// TODO Auto-generated constructor stub

}

AdEntry::~AdEntry() {
	// TODO Auto-generated destructor stub
}


