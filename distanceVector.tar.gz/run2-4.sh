#! /bin/bash
cd Release
./distanceVector configfile2-4 65531 100 16 30 true 
