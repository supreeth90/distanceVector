#! /bin/bash
cd Release
./distanceVector configfile1 65531 100 16 30 true 
