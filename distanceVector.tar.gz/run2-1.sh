#! /bin/bash
cd Release
./distanceVector configfile2-1 65531 100 16 30 true 
