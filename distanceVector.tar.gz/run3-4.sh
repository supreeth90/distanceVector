#! /bin/bash
cd Release
./distanceVector configfile3-4 65531 100 16 30 false 
