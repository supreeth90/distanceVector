#! /bin/bash
cd Release
./distanceVector configfile3 65531 100 16 30 true 
