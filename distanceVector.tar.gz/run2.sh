#! /bin/bash
cd Release
./distanceVector configfile2 65531 100 16 30 false 
